import { useState, useContext } from 'react';
import { UserContext } from '../../../context/userContext';
import { Link, useNavigate } from 'react-router-dom';
import './navbar.css'; // Import your CSS file

const Navbar = () => {
  const { user, setUser } = useContext(UserContext); // Access the user context
  const [cartCount, setCartCount] = useState(0); // Placeholder for cart count
  const [wishlistCount, setWishlistCount] = useState(0); // Placeholder for wishlist count
  const navigate = useNavigate();

  const handleLogout = () => {
    // Clear the authentication token from localStorage
    localStorage.removeItem('authToken');
    setUser(null);
    // Redirect to the login page
    navigate('/login');
  };

  return (
    <div>
      {user ? (
        <div className="main-navbar shadow-sm sticky-top">
          <div className="top-navbar">
            <div className="container-fluid">
              <div className="row">
                <div className="col-md-2 my-auto d-none d-sm-none d-md-block d-lg-block">
                  <h5 className="brand-name">Funda Ecom</h5>
                </div>
                <div className="col-md-5 my-auto">
                  <form role="search">
                    <div className="input-group d-flex align-items-center">
                      <input
                        type="search"
                        placeholder="Search your product"
                        className="form-control"
                      />
                      <button
                        className="btn bg-white"
                        type="submit"
                        style={{ height: '38px', padding: '0 10px' }}
                      >
                        <i className="fa fa-search"></i>
                      </button>
                    </div>
                  </form>
                </div>
                <div className="col-md-5 my-auto">
                  <ul className="nav justify-content-end">
                    <li className="nav-item">
                      <Link className="nav-link" to="addtocart">
                        <i className="fa fa-shopping-cart"></i> Cart ({cartCount})
                      </Link>
                    </li>
                    <li className="nav-item">
                      <Link className="nav-link" to="addtowishlist">
                        <i className="fa fa-heart"></i> Wishlist ({wishlistCount})
                      </Link>
                    </li>
                    <li className="nav-item dropdown">
                      <Link
                        className="nav-link dropdown-toggle"
                        to="#"
                        id="navbarDropdown"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        <i className="fa fa-user"></i> {user?.username || 'User'}
                      </Link>
                      <ul className="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li>
                          <Link className="dropdown-item" to="#">
                            <i className="fa fa-user"></i> Profile
                          </Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#">
                            <i className="fa fa-list"></i> My Orders
                          </Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="wishlist">
                            <i className="fa fa-heart"></i> My Wishlist
                          </Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#">
                            <i className="fa fa-shopping-cart"></i> My Cart
                          </Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" onClick={handleLogout} to="/">
                            <i className="fa fa-sign-out"></i> Logout
                          </Link>
                        </li>
                      </ul>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="main-navbar shadow-sm sticky-top">
          <div className="top-navbar">
            <div className="container-fluid">
              <div className="row">
                <div className="col-md-2 my-auto d-none d-sm-none d-md-block d-lg-block">
                  <h5 className="brand-name">Funda Ecom</h5>
                </div>
                <div className="col-md-5 my-auto">
                  <form role="search">
                    <div className="input-group d-flex align-items-center">
                      <input
                        type="search"
                        placeholder="Search your product"
                        className="form-control"
                      />
                      <button
                        className="btn bg-white"
                        type="submit"
                        style={{ height: '38px', padding: '0 10px' }}
                      >
                        <i className="fa fa-search"></i>
                      </button>
                    </div>
                  </form>
                </div>
                <div className="col-md-5 my-auto">
                  <ul className="nav justify-content-end">
                    <li className="nav-item">
                    <li className="nav-item">
                      <Link className="nav-link" to="addtocart">
                        <i className="fa fa-shopping-cart"></i> Cart ({cartCount})
                      </Link>
                    </li>
                    </li>
                    <li className="nav-item">
                      <Link className="nav-link" to="/register">
                        Sign Up
                      </Link>
                    </li>
                  </ul>
                  <div>
                  <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="nav-item">
                <Link className="nav-link" to="#">Home</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="category">All Categories</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="#">New Arrivals</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="#">Featured Products</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="see/electronics">Electronics</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="#">Fashions</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="#">Accessories</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="#">Home</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="#">Appliances</Link>
              </li>
            </ul></div>
                  </div>

                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Navbar;




