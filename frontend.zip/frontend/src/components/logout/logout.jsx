// src/compts/Logout.js
import React from 'react';
import { useNavigate } from 'react-router-dom';

function Logout() {
  const navigate = useNavigate();

  const handleLogout = () => {
    // Clear the authentication token from localStorage
    localStorage.removeItem('authToken');

    // Redirect to the login page
    navigate('/login');
  };

  return (
    <button onClick={handleLogout} className="nav-link text-white bg-transparent border-0">
      <i className="bi bi-box-arrow-right"></i> Logout
    </button>
  );
}

export default Logout;
