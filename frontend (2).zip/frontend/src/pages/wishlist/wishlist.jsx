
import react from 'react'


 function wishlist() {
  
 return(
    <>heyyy</>
 )
}
export default wishlist;