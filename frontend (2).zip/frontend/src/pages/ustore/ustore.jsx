// Ustore.js
import React, { useEffect, useState, useContext} from 'react';
import { Card, Row, Col } from 'react-bootstrap';
import { Link } from 'react-router-dom';
// import { useWishlist } from '../../../context/WishlistContext';
import { useCart } from 'react-use-cart';
import { FaHeart, FaShoppingCart, FaTags } from 'react-icons/fa';
import axios from 'axios';
// import { useState } from 'react';
import { UserContext } from '../../../context/userContext';
import './ustore.css'

function Ustore() {

const [data, setData] = useState([]);
const { user } = useContext(UserContext); // Fetch user context
const { addItem } = useCart();
  

  useEffect(() => {
    fetch('http://localhost:8000/products/get', {
      method: 'GET'
    })
      .then((res) => res.json())
      .then((products) => {
        console.log('Fetched Products:', products);
        setData(products);
      })
      .catch((error) => console.error('Error fetching products:', error));
  }, []);
 
// Handle Add to Wishlist
const handleAddToWishlist = async (product) => {
  const userId = user?.id; // Ensure userId is available
  if (!userId) {
    console.error('User is not logged in');
    alert('Please log in to add items to your wishlist.');

    return;
  }

  try {
    const response = await axios.post('http://localhost:8000/api/wishlist/add', {
      userId,
      productId: product._id, // Assuming product has an '_id' field
    });
    console.log('Added to wishlist:', response.data);
      alert('Product added to wishlist!');
  } catch (err) {
    console.error('Failed to add to wishlist:', err);
  }
};



  return (
    <div className="card-wrapper">
      <Row className="g-4">
        {data.map((product, index) => (
          <Col key={index} xs={12} md={6} lg={3} className="mb-4">
            <Card style={{ width: '18rem' }} className="shadow-sm border-0 h-100">
              <Card.Img
                variant="top"
                src={`http://localhost:8000/images/${product?.image}`}
                alt={product?.name || 'No Name'}
                style={{ height: '250px', objectFit: 'cover' }}
              />
              <Card.Body>
                <Card.Title>{product?.name || 'No Name'}</Card.Title>
                <Card.Text>
                  {product?.description || 'Some quick example text to build on the card title.'}
                </Card.Text>
                <div className="d-flex justify-content-between align-items-center mb-3">
                  <span style={{ fontWeight: 'bold', color: '#333' }}>
                    ${product?.price || 'N/A'}
                  </span>
                  <span className="text-muted" style={{ fontSize: '0.85rem' }}>
                    {product?.category || 'N/A'}
                  </span>
                </div>
                <div className="d-flex justify-content-between">
                 <div>
                  <FaHeart
                   onClick={() => handleAddToWishlist(product)}
                    className="text-danger"
                    size={24}
                    style={{ cursor: 'pointer' }}
                    title="Add to Wish List"
                   
                  />
               
                  </div>
                          
                  <FaShoppingCart

                    onClick={() => addItem({ id: product._id, ...product })
                 
                                           
                  
                  
                  }
                    className="text-primary"
                    size={24}
                    style={{ cursor: 'pointer' }}
                    title="Add to Cart"
                  />
                  <Link to={`/sell-product/${product._id}/${product.name}/${product.price}/${product.amount}`}>
                    <FaTags
                      className="text-success"
                      size={24}
                      style={{ cursor: 'pointer' }}
                      title="Buy"
                    />
                  </Link>
                </div>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>
    </div>
  );
}

export default Ustore;





















