import {useState} from 'react'
import axios from 'axios';
import {toast} from 'react-hot-toast'
import {useNavigate} from 'react-router-dom'
import Navbar from '../../components/navbar/navbar';

 function Login() {
  const navigate = useNavigate()
  const[data,setData] = useState({
    email: '',
    password: '',
  })

    const loginUser =async(e)=>{
        e.preventDefault()
       const {email,password} = data;
       try{
const{data} = await  axios.post('/login',{
  email,
  password
});
if(data.error){
  toast.error(data.error)
} else setData({})
navigate('/dashboard')
          }catch(error){
console.log(error)
          }}
  return (
    <div>
      <Navbar/>
   <form onSubmit={loginUser}>
   <div className="d-flex justify-content-center " style={{ minHeight: '60vh', alignItems: 'center' }}>
      <div className="card" style={{ width: '20rem' }}>
        <div className="card-body">
        <h5 className="card-title text-center">Login To Your Account</h5>
          <div className="form-floating mb-3">
            <input
              type="email"
              className="form-control"
              id="floatingInput"
              name="email"
              placeholder="name@example.com"
              value={data.email} 
         onChange={(e)=> setData({...data, email: e.target.value})}



         autoComplete="off" />
            <label htmlFor="floatingInput">Email address</label>
          </div>
          <div className="form-floating">
            <input
              type="password"
              className="form-control"
              id="floatingPassword"
              name="password"
              placeholder="Password"
              value={data.password} onChange={(e)=> setData({...data, password: e.target.value})}


              autoComplete="off" />
            <label htmlFor="floatingPassword">Password</label>
          </div>
          {/* Centering the button */}
          <div className="d-flex justify-content-center mt-3">
            <button type="submit" className="btn btn-primary  w-100 mt-3 ">Login</button>
          </div>
        </div>
      </div>
    </div>
   
   </form>
    </div>
  )
}
export default Login;